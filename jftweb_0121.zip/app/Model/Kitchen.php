<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Kitchen extends Model
{
    //
    protected $table = 'groups';
}
