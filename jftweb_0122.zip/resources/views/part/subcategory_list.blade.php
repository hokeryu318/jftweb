@foreach ($subs as $sub)
    @include('part.subcategory_item')
@endforeach
