<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DishOrder extends Model
{
    //
    protected $table = 'dish_order_match';
}
