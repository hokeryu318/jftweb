<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Timeslot extends Model
{
    //
    protected $table = 'timeslots';
}
