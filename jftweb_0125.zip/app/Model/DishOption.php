<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DishOption extends Model
{
    //
    protected $table = 'dish_option_match';
}
