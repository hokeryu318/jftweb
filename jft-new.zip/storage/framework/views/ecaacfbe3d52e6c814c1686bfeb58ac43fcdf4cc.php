<?php $__env->startSection('title', 'DISH'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .option-padding {
        padding-top : 0.6rem;
        padding-bottom : 0.6rem;
    }
</style>
<div class="container-fluid pb-3 blackgrey">
    <form method="POST" action="<?php echo e(route('admin.dish.store')); ?>" enctype='multipart/form-data'>
    <input type="hidden" value="<?php echo e($obj->id); ?>" name="id">
    <div style="padding-top:8%;">
    </div>
    <div class="widthh white pt-3 pb-1 position-relative">
        <div class="row">
            <div class="col-11">
            </div>
            <div class="col-1">
                <a>
                    <span class="">
                        <img src="<?php echo e(asset('img/Group1100.png')); ?>" height="20" class="float-right" width="20" />
                    </span>
                </a>
            </div>
        </div>
    <div>
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Name of dish</label>
                </div>
                <input type="text" class="outline-0 border-blue h4rem" name="name_en" value="<?php echo e($obj->name_en); ?>" />
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Name of dish (Mandarine)</label>
                </div>
                <input type="text" class="outline-0 border-blue h4rem" name="name_cn" value="<?php echo e($obj->name_cn); ?>" />
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Name of dish (Japanese)</label>
                </div>
                <input type="text" class="outline-0 border-blue h4rem" name="name_jp" value="<?php echo e($obj->name_jp); ?>" />
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Description</label>
                </div>
                <input type="text" class="outline-0 border-blue h4rem" name="desc_en" value="<?php echo e($obj->desc_en); ?>" />
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Description (Mandarine)</label>
                </div>
                <input type="text" class="outline-0 border-blue h4rem" name="desc_cn" value="<?php echo e($obj->desc_cn); ?>" />
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Description (Japanese)</label>
                </div>
                <input type="text" class="outline-0 border-blue h4rem"  name="desc_jp" value="<?php echo e($obj->desc_jp); ?>" />
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Price</label>
                </div>
                <input type="number" class="outline-0 border-blue" name="price" step="0.01" value="<?php echo e($obj->price); ?>" />
                <p class="text-right text-blue" >(Included GST: $ 1.13)</p>
            </div>
        </div>
        <div class="col-6">
            <div class="addphoto">
                <button class="create_addPhotobtn" type="button" id="btn_add_image" onclick="setPhoto()"
                <?php if($obj->image != null): ?>
                    style="display:none"
                <?php endif; ?>
                >Add Photo</button>
                <img id="main_img" width="100%" height="100%"
                <?php if($obj->image != null): ?>
                    src="<?php echo e(asset('dishes/'.$obj->image)); ?>"
                <?php endif; ?>
                >
                <input type="file" id="image_file" name="image" style="display:none">
            </div>
            <button class="create_changePhotobtn" type="button" id="btn_change_image" onclick="setPhoto()"
                <?php if($obj->image == null): ?>
                    style="display:none"
                <?php endif; ?>
            >Change Photo</button>
        </div>
    </div>
    <div class="row">
        <div class="col-7" id="content">
            <label class="text-blue txtdemibold">Option</label>
            <?php $__currentLoopData = $obj->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-2 option-element">
                    <select class="border-blue select-width-blue mr-1 option-padding option-select" name="opts[]">
                        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($o->id); ?>"
                            <?php if($opt->id == $o->id): ?>
                                selected
                            <?php endif; ?>
                            ><?php echo e($o->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btndeletebehind mt-2" type="button" onclick="onDeleteOption(this)">Delete</button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <button class="addOptionbtn mt-3 mb-4" type="button" onclick="onAddOption()">Add Option </button>
    <div class="mt-2 option-element" style="display:none" id="clone">
        <select class="border-blue select-width-blue mr-1 option-padding option-select" name="option">
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($o->id); ?>"><?php echo e($o->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btndeletebehind mt-2" type="button" onclick="onDeleteOption(this)">Delete</button>
    </div>
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Category</label>
                </div>
                <select type="text" class="outline-0 border-blue w-100 option-padding" name="category_id" id="mcategory">
                    <option value="0">--Select Category--</option>
                    <?php $__currentLoopData = $main_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"
                        <?php if($cat->id == $obj->category_id): ?>
                            selected
                        <?php endif; ?>
                        ><?php echo e($cat->name_en); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Sub-Category</label>
                </div>
                <select type="text" class="outline-0 border-blue w-100 option-padding" name="sub_category_id" id="scategory">
                    <option value="0">--Select Sub-Category--</option>
                    <?php if($obj->id != null): ?>
                    <?php $__currentLoopData = $sub_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subcat->id); ?>"
                        <?php if($subcat->id == $obj->sub_category_id): ?>
                            selected
                        <?php endif; ?>
                        ><?php echo e($subcat->name_en); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Group</label>
                </div>
                <select type="text" class="outline-0 border-blue w-100 option-padding" id="group" name="group_id">
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($g->id); ?>"
                        <?php if($g->id == $obj->group_id): ?>
                            selected
                        <?php endif; ?>
                        > <?php echo e($g->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <div>
                    <label class="text-blue txtdemibold">Badge</label>
                </div>
                <select type="text" class="outline-0 border-blue w-100 option-padding" name="badge_id">
                    <option value="0">--Select Badge--</option>
                    <?php $__currentLoopData = $badges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->id); ?>"
                        <?php if($b->id == $obj->badge_id): ?>
                            selected
                        <?php endif; ?>
                        > <?php echo e($b->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>


    <div class="row mt-5">
        <div class="col-6">
            <label class="text-blue txtdemibold ">Eat-in</label>
            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Breakfast</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="eatin_breakfast"
                                <?php if($obj->eatin_breakfast == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Lunch</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="eatin_lunch"
                                <?php if($obj->eatin_lunch == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>

                    </div>
                </div>
            </div>
            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Tea</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="eatin_tea"
                                <?php if($obj->eatin_tea == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Dinner</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="eatin_dinner"
                                <?php if($obj->eatin_dinner == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <label class="text-blue txtdemibold">Takeaway</label>
            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Breakfast</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="takeaway_breakfast"
                                <?php if($obj->takeaway_breakfast == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Lunch</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="takeaway_lunch"
                                <?php if($obj->takeaway_lunch == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Tea</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="takeaway_tea"
                                <?php if($obj->takeaway_tea == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="border-bottom-blue">
                <div class="row">
                    <div class="col-8"><label class="txtdemibold mt-2">Dinner</label></div>
                    <div class="col-4">
                        <div class="float-right mt-2">
                            <label class="bs-switch ">
                                <input type="checkbox" name="takeaway_dinner"
                                <?php if($obj->takeaway_dinner == 1): ?>
                                    checked
                                <?php endif; ?>
                                >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-5 mb-5">
        <div class="col-7 mt-4">
            <button class="grey-button">
                DELETE
                <img src="<?php echo e(asset('img/Group728.png')); ?>" height="20" class="mb-1" />
            </button>
        </div>
        <div class="col-5 mt-4">
            <button class="grey-button ml-5">
                CANCEL
                <img src="<?php echo e(asset('img/Group728.png')); ?>" height="20" class="mb-1" />
            </button>
            <button class="green-button">
                Apply
                <img src="<?php echo e(asset('img/Group728white.png')); ?>" height="20" class="mb-1" />
            </button>
        </div>
    </div>
    <?php echo csrf_field(); ?>
    </form>
</div>
<script>
    $(document).ready(function(){
        console.log($('#mcategory').val());
        <?php if($obj->id == null): ?>
            $('#mcategory').trigger('change');
        <?php endif; ?>
    });
    $('#mcategory').change(function(){
        var main = $(this).val();
        $.ajax({
            type:"POST",
            url:"<?php echo e(route('admin.category.subs')); ?>",
            data:{
                parent:main,
                _token:"<?php echo e(csrf_token()); ?>"
            },
            success: function(result){
                $('#scategory').html(result);
            }
        });
    });
    function setPhoto()
    {
        $('#image_file').trigger('click');
    }
    $('#image_file').change(function(ev){
        var f = ev.target.files[0];
        var fr = new FileReader();
        var img = $('#main_img');
        fr.onload = function(ev2) {
            $(img).attr('src', ev2.target.result);
            $(img).show();
            $('#btn_add_image').hide();
            $('#btn_change_image').show();
        };

        fr.readAsDataURL(f);
    });
    function onAddOption()
    {
        var div = $('#clone').clone();
        $('.option-select', div).attr('name', 'opts[]');
        $(div).show();
        $('#content').append(div);
    }
    function onDeleteOption(obj)
    {
        var parent = $(obj).closest('.option-element');
        $(parent).remove();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>