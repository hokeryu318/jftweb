@extends('layout.admin_layout')

@section('title', 'Home')

@section('content')

@endsection
