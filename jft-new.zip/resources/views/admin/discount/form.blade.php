@extends('layout.admin_layout')

@section('title', 'DISH')

@section('content')

@endsection
